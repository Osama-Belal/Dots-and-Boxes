#ifndef PLAYING_H_INCLUDED
#define PLAYING_H_INCLUDED

#include "playing.c"

#endif // PLAYING_H_INCLUDED


void print_board(int scores[], int moves[], int maxmoves, int time_spent);
int game(char  x);
