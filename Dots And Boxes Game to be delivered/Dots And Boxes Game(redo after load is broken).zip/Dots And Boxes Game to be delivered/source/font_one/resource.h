//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by font_one.rc
//
#define IDR_MENU                        101
#define ID_FILE_EXIT                    40001
#define ID_FORMAT_FONT                  40002
#define ID_FORMAT_BACKGROUNDCOLOUR      40003
#define ID_FORMAT_OPAQUE                40004
#define ID_FORMAT_DEFAULTGUIFONT        40005
#define ID_FORMAT_TEST                  40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
