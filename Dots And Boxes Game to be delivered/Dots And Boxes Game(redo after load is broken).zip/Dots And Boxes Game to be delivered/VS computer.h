#ifndef VS_COMPUTER_INCLUDED
#define VS_COMPUTER_INCLUDED

#include "VS computer.c"

#endif // VS_COMPUTER_INCLUDED


int vs_computer(char x);
