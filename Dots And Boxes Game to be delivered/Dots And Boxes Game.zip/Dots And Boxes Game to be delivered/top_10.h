#ifndef TOP_TEN_INCLUDED
#define TOP_TEN_INCLUDED

#include "top_10.c"

#endif // TOP_10_INCLUDED


void top_ten_list();
